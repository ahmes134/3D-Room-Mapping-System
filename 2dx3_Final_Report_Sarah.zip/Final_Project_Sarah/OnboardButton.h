void EnableInt(void);
void DisableInt(void);
void WaitForInt(void);

void PortJ_Init(void);
void PortJ_Interrupt_Init(void);